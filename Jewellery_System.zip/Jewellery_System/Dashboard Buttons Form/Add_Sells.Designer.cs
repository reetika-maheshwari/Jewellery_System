﻿
namespace Jewellery_System
{
    partial class Add_Sells
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtContactnumber = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnStartBilling = new Guna.UI2.WinForms.Guna2Button();
            this.labelContactus = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.labelcustomername = new System.Windows.Forms.Label();
            this.textBoxcustomername = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.txtContactnumber);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.btnStartBilling);
            this.panel1.Controls.Add(this.labelContactus);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.labelcustomername);
            this.panel1.Controls.Add(this.textBoxcustomername);
            this.panel1.Location = new System.Drawing.Point(2, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(706, 183);
            this.panel1.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(684, 7);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(17, 16);
            this.label4.TabIndex = 48;
            this.label4.Text = "X";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Californian FB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(461, 78);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(20, 22);
            this.label1.TabIndex = 46;
            this.label1.Text = "*";
            // 
            // txtContactnumber
            // 
            this.txtContactnumber.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtContactnumber.Location = new System.Drawing.Point(356, 100);
            this.txtContactnumber.Multiline = true;
            this.txtContactnumber.Name = "txtContactnumber";
            this.txtContactnumber.Size = new System.Drawing.Size(315, 26);
            this.txtContactnumber.TabIndex = 47;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Californian FB", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label2.Location = new System.Drawing.Point(353, 78);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(113, 18);
            this.label2.TabIndex = 45;
            this.label2.Text = "Contact Number";
            // 
            // btnStartBilling
            // 
            this.btnStartBilling.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnStartBilling.BorderRadius = 10;
            this.btnStartBilling.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnStartBilling.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnStartBilling.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnStartBilling.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnStartBilling.FillColor = System.Drawing.Color.RosyBrown;
            this.btnStartBilling.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.btnStartBilling.ForeColor = System.Drawing.Color.White;
            this.btnStartBilling.Location = new System.Drawing.Point(11, 136);
            this.btnStartBilling.Name = "btnStartBilling";
            this.btnStartBilling.Size = new System.Drawing.Size(119, 34);
            this.btnStartBilling.TabIndex = 44;
            this.btnStartBilling.Text = "Start Billing";
            this.btnStartBilling.Click += new System.EventHandler(this.btnStartBilling_Click);
            // 
            // labelContactus
            // 
            this.labelContactus.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelContactus.AutoSize = true;
            this.labelContactus.Font = new System.Drawing.Font("Californian FB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelContactus.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.labelContactus.Location = new System.Drawing.Point(2, 19);
            this.labelContactus.Name = "labelContactus";
            this.labelContactus.Size = new System.Drawing.Size(214, 22);
            this.labelContactus.TabIndex = 33;
            this.labelContactus.Text = "Product Billing Dashboard";
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Californian FB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(110, 75);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(20, 22);
            this.label5.TabIndex = 38;
            this.label5.Text = "*";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label3.Location = new System.Drawing.Point(4, 41);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(696, 16);
            this.label3.TabIndex = 34;
            this.label3.Text = "_________________________________________________________________________________" +
    "_____";
            // 
            // labelcustomername
            // 
            this.labelcustomername.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelcustomername.AutoSize = true;
            this.labelcustomername.Font = new System.Drawing.Font("Californian FB", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelcustomername.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.labelcustomername.Location = new System.Drawing.Point(7, 78);
            this.labelcustomername.Name = "labelcustomername";
            this.labelcustomername.Size = new System.Drawing.Size(109, 18);
            this.labelcustomername.TabIndex = 35;
            this.labelcustomername.Text = "Customer Name";
            // 
            // textBoxcustomername
            // 
            this.textBoxcustomername.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxcustomername.Location = new System.Drawing.Point(10, 100);
            this.textBoxcustomername.Multiline = true;
            this.textBoxcustomername.Name = "textBoxcustomername";
            this.textBoxcustomername.Size = new System.Drawing.Size(315, 26);
            this.textBoxcustomername.TabIndex = 37;
            // 
            // Add_Sells
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.RosyBrown;
            this.ClientSize = new System.Drawing.Size(710, 190);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Add_Sells";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add_Sells";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private Guna.UI2.WinForms.Guna2Button btnStartBilling;
        private System.Windows.Forms.Label labelContactus;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label labelcustomername;
        private System.Windows.Forms.TextBox textBoxcustomername;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtContactnumber;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
    }
}