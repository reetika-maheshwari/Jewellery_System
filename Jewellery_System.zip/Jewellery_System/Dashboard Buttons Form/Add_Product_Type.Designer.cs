﻿
namespace Jewellery_System
{
    partial class Add_Product_Type
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxdescription = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnSaveProductType = new Guna.UI2.WinForms.Guna2Button();
            this.labelContactus = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.labelcustomername = new System.Windows.Forms.Label();
            this.textBoxproducttypetitle = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.textBoxdescription);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.btnSaveProductType);
            this.panel1.Controls.Add(this.labelContactus);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.labelcustomername);
            this.panel1.Controls.Add(this.textBoxproducttypetitle);
            this.panel1.Location = new System.Drawing.Point(4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(706, 270);
            this.panel1.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(680, 5);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(21, 20);
            this.label4.TabIndex = 48;
            this.label4.Text = "X";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Californian FB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(86, 121);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(20, 22);
            this.label1.TabIndex = 46;
            this.label1.Text = "*";
            // 
            // textBoxdescription
            // 
            this.textBoxdescription.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxdescription.Location = new System.Drawing.Point(11, 144);
            this.textBoxdescription.Multiline = true;
            this.textBoxdescription.Name = "textBoxdescription";
            this.textBoxdescription.Size = new System.Drawing.Size(536, 57);
            this.textBoxdescription.TabIndex = 47;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Californian FB", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label2.Location = new System.Drawing.Point(8, 122);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 18);
            this.label2.TabIndex = 45;
            this.label2.Text = "Description";
            // 
            // btnSaveProductType
            // 
            this.btnSaveProductType.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnSaveProductType.BorderRadius = 5;
            this.btnSaveProductType.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnSaveProductType.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnSaveProductType.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnSaveProductType.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnSaveProductType.FillColor = System.Drawing.Color.RosyBrown;
            this.btnSaveProductType.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.btnSaveProductType.ForeColor = System.Drawing.Color.White;
            this.btnSaveProductType.Location = new System.Drawing.Point(11, 217);
            this.btnSaveProductType.Name = "btnSaveProductType";
            this.btnSaveProductType.Size = new System.Drawing.Size(146, 36);
            this.btnSaveProductType.TabIndex = 44;
            this.btnSaveProductType.Text = "Save Product Type";
            this.btnSaveProductType.Click += new System.EventHandler(this.btnStartBilling_Click);
            // 
            // labelContactus
            // 
            this.labelContactus.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelContactus.AutoSize = true;
            this.labelContactus.Font = new System.Drawing.Font("Californian FB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelContactus.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.labelContactus.Location = new System.Drawing.Point(6, 12);
            this.labelContactus.Name = "labelContactus";
            this.labelContactus.Size = new System.Drawing.Size(151, 22);
            this.labelContactus.TabIndex = 33;
            this.labelContactus.Text = "Add Product Type";
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Californian FB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(134, 61);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(20, 22);
            this.label5.TabIndex = 38;
            this.label5.Text = "*";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label3.Location = new System.Drawing.Point(8, 34);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(696, 16);
            this.label3.TabIndex = 34;
            this.label3.Text = "_________________________________________________________________________________" +
    "_____";
            // 
            // labelcustomername
            // 
            this.labelcustomername.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelcustomername.AutoSize = true;
            this.labelcustomername.Font = new System.Drawing.Font("Californian FB", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelcustomername.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.labelcustomername.Location = new System.Drawing.Point(8, 63);
            this.labelcustomername.Name = "labelcustomername";
            this.labelcustomername.Size = new System.Drawing.Size(130, 18);
            this.labelcustomername.TabIndex = 35;
            this.labelcustomername.Text = "Product Type Title";
            // 
            // textBoxproducttypetitle
            // 
            this.textBoxproducttypetitle.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxproducttypetitle.Location = new System.Drawing.Point(11, 84);
            this.textBoxproducttypetitle.Multiline = true;
            this.textBoxproducttypetitle.Name = "textBoxproducttypetitle";
            this.textBoxproducttypetitle.Size = new System.Drawing.Size(536, 26);
            this.textBoxproducttypetitle.TabIndex = 37;
            // 
            // Add_Product_Type
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.RosyBrown;
            this.ClientSize = new System.Drawing.Size(714, 279);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Add_Product_Type";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add_Product_Type";
//            this.Load += new System.EventHandler(this.Add_Product_Type_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxdescription;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2Button btnSaveProductType;
        private System.Windows.Forms.Label labelContactus;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label labelcustomername;
        private System.Windows.Forms.TextBox textBoxproducttypetitle;
    }
}